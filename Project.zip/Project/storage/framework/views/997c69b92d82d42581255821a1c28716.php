

<?php $__env->startSection('content'); ?>
    <div class="text-center mb-8">
        <h2 class="text-3xl font-semibold text-gray-800">Medications List</h2>
        <p class="text-gray-600 mt-2">Manage your medications and their schedules.</p>
    </div>

    <div class="flex justify-end mb-6">
        <a href="<?php echo e(route('medications.create')); ?>" class="bg-indigo-600 text-white py-2 px-6 rounded-md hover:bg-indigo-700 transition-colors">Add New Medication</a>
    </div>

    <div class="space-y-4">
        <?php $__currentLoopData = $medications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $medication): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="bg-white shadow-md rounded-lg p-6 flex justify-between items-center">
                <div>
                    <h3 class="text-xl font-medium text-gray-800"><?php echo e($medication->name); ?></h3>
                    <p class="text-gray-600">Dosage: <?php echo e($medication->dosage); ?> | Frequency: <?php echo e($medication->frequency); ?></p>
                </div>
                <div class="flex space-x-4">
                    <a href="<?php echo e(route('medications.edit', $medication)); ?>" class="text-indigo-600 hover:text-indigo-700 transition-colors">Edit</a>
                    <form action="<?php echo e(route('medications.destroy', $medication)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="text-red-600 hover:text-red-700 transition-colors">Delete</button>
                    </form>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ASUS\Herd\project\resources\views/medications/index.blade.php ENDPATH**/ ?>