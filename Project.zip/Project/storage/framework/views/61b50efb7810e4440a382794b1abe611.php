<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Smart Healthcare Reminder System</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600&display=swap" rel="stylesheet">
    <!-- TailwindCSS CDN -->
    <script src="https://cdn.tailwindcss.com"></script>

<!-- AlpineJS for interactivity -->
<script src="https://cdn.jsdelivr.net/npm/alpinejs@2.8.2/dist/alpine.min.js" defer></script>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
</head>
<body class="bg-gray-50 font-inter antialiased">

    <!-- Navbar -->
    <nav class="bg-white shadow-md py-4">
        <div class="max-w-7xl mx-auto px-6 flex justify-between items-center">
            <a href="/" class="text-2xl font-semibold text-gray-800 hover:text-indigo-600 transition-colors">Health Reminder</a>
            <div class="space-x-6">
                <a href="<?php echo e(route('medications.index')); ?>" class="text-gray-600 hover:text-indigo-600 transition-colors">Medications</a>
                <a href="<?php echo e(route('welcome')); ?>" class="text-gray-600 hover:text-indigo-600 transition-colors">Home</a>
                <?php if(auth()->guard()->check()): ?>
                    <a href="<?php echo e(route('logout')); ?>" class="text-gray-600 hover:text-indigo-600 transition-colors">Logout</a>
                <?php else: ?>
                    <a href="<?php echo e(route('login')); ?>" class="text-gray-600 hover:text-indigo-600 transition-colors">Login</a>
                    <a href="<?php echo e(route('register')); ?>" class="text-gray-600 hover:text-indigo-600 transition-colors">Register</a>
                <?php endif; ?>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <main class="py-12">
        <div class="max-w-7xl mx-auto px-6">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </main>

    <!-- Footer (Optional) -->
    <footer class="bg-gray-200 py-6">
        <div class="text-center text-gray-600">
            <p>&copy; <?php echo e(date('Y')); ?> Healthcare Reminder. All rights reserved.</p>
        </div>
    </footer>
</body>
</html>
<?php /**PATH C:\Users\ASUS\Herd\project\resources\views/layouts/app.blade.php ENDPATH**/ ?>