

<?php $__env->startSection('content'); ?>
    <div class="text-center mb-8">
        <h2 class="text-3xl font-semibold text-gray-800">Add New Medication</h2>
        <p class="text-gray-600 mt-2">Enter your medication details below.</p>
    </div>

    <div class="max-w-2xl mx-auto bg-white shadow-md rounded-lg p-8">
        <form action="<?php echo e(route('medications.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="mb-4">
                <label for="name" class="block text-gray-700">Medication Name</label>
                <input type="text" name="name" id="name" class="w-full p-3 mt-2 border border-gray-300 rounded-md" required>
            </div>

            <div class="mb-4">
                <label for="dosage" class="block text-gray-700">Dosage</label>
                <input type="text" name="dosage" id="dosage" class="w-full p-3 mt-2 border border-gray-300 rounded-md" required>
            </div>

            <div class="mb-4">
                <label for="frequency" class="block text-gray-700">Frequency</label>
                <input type="text" name="frequency" id="frequency" class="w-full p-3 mt-2 border border-gray-300 rounded-md" required>
            </div>

            <div class="mb-4">
                <label for="start_date" class="block text-gray-700">Start Date</label>
                <input type="date" name="start_date" id="start_date" class="w-full p-3 mt-2 border border-gray-300 rounded-md" required>
            </div>

            <div class="mb-4">
                <label for="end_date" class="block text-gray-700">End Date</label>
                <input type="date" name="end_date" id="end_date" class="w-full p-3 mt-2 border border-gray-300 rounded-md" required>
            </div>

            <button type="submit" class="w-full bg-indigo-600 text-white py-3 rounded-md hover:bg-indigo-700 transition-colors">Save Medication</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ASUS\Herd\Project\resources\views/medications/create.blade.php ENDPATH**/ ?>