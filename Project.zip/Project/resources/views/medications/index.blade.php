@extends('layouts.app')

@section('content')
    <!-- Header Section -->
    <div class="text-center mb-8">
        <h2 class="text-3xl font-semibold text-gray-900">Medications List</h2>
        <p class="text-black-600 mt-2">Easily manage your medications and schedules.</p>
    </div>

    <!-- Add Medication Button -->
    <div class="flex justify-end mb-6">
        <a href="{{ route('medications.create') }}" 
           class="bg-blue-600 text-white py-2 px-6 rounded-lg shadow hover:bg-blue-700 transition-all focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2">
            Add New Medication
        </a>
    </div>

    <!-- Medications List -->
    <div class="space-y-4">
        @foreach ($medications as $medication)
            <div class="bg-white shadow-lg rounded-lg p-6 flex justify-between items-center border border-gray-200 hover:shadow-xl transition-shadow">
                <!-- Medication Details -->
                <div>
                    <h3 class="text-xl font-semibold text-gray-900">{{ $medication->name }}</h3>
                    <p class="text-gray-700 mt-1">Dosage: <span class="font-medium">{{ $medication->dosage }}</span> | Frequency: <span class="font-medium">{{ $medication->frequency }}</span></p>
                </div>

                <!-- Action Buttons -->
                <div class="flex space-x-4">
                    <a href="{{ route('medications.edit', $medication) }}" 
                       class="text-blue-600 hover:text-blue-700 font-medium transition-colors focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2">
                        Edit
                    </a>
                    <form action="{{ route('medications.destroy', $medication) }}" method="POST" onsubmit="return confirm('Are you sure you want to delete this medication?');">
                        @csrf
                        @method('DELETE')
                        <button type="submit" 
                                class="text-red-600 hover:text-red-700 font-medium transition-colors focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-offset-2">
                            Delete
                        </button>
                    </form>
                </div>
            </div>
        @endforeach
    </div>
@endsection
