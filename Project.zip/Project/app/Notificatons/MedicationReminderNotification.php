<?php

namespace App\Notifications;

use Illuminate\Notifications\Notification;
use Illuminate\Notifications\Messages\MailMessage;

class MedicationReminderNotification extends Notification
{
    private $medication;

    /**
     * Create a new notification instance.
     */
    public function __construct($medication)
    {
        $this->medication = $medication;
    }

    /**
     * Get the notification's delivery channels.
     */
    public function via($notifiable)
    {
        return ['database', 'mail'];
    }

    /**
     * Get the array representation of the notification.
     */
    public function toDatabase($notifiable)
    {
        return [
            'medication_id' => $this->medication->id,
            'message' => "It's time to take your medication: {$this->medication->name}",
        ];
    }

    /**
     * Get the mail representation of the notification.
     */
    public function toMail($notifiable)
    {
        return (new MailMessage)
                    ->line("It's time to take your medication: {$this->medication->name}")
                    ->action('Mark as Taken', route('medications.markAsTaken', $this->medication->id))
                    ->line('Thank you for using our healthcare medicine reminder app!');
    }
}
