<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Medication extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'name',
        'dosage',
        'frequency',
        'start_date',
        'end_date',
        'remaining_doses', // Already present
        'next_reminder_time', // New addition
    ];
}
